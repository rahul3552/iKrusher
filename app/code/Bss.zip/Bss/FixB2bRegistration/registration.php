<?php
// @codingStandardsIgnoreFile

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Bss_FixB2bRegistration',
    __DIR__
);
