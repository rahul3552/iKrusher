var config = {
    config: {
        mixins: {
            'Magento_Customer/js/view/authentication-popup': {
                'Bss_B2bRegistration/js/view/authentication-popup-mixin': true
            }
        }
    }
};
