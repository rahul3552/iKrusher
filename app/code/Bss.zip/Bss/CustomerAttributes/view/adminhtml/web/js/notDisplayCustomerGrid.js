define([], function(){
    'use strict';

    return function(config){
        window.notDisplayCustomerGrid = config.notDisplayCustomerGrid;
    }
});
