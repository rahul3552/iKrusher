<?php
namespace MGS\ThemeSettings\Model\OptimizeWeb\Handle;

class Css
{
    /**
     * @param string $html
     *
     * @return $this
     */
    public function deferParsingOfCss(&$html)
    {
        return $this;
    }
}
