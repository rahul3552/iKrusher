var config = {
	paths: {
		'mgs/notifyslider'			: 'MGS_PurchasedProduct/js/notifyslider'
	},

	shim: {
		'mgs/notifyslider': {
			deps: ['jquery']
		}
	}

};