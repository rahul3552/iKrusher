var config = {
    config: {
        mixins: {
            'Magento_Wishlist/js/add-to-wishlist': {
                'MGS_Guestwishlist/js/add-to-wishlist': true
            },
            'Magento_Wishlist/js/view/wishlist': {
                'MGS_Guestwishlist/js/view/guest-wishlist': true
            }
        }
    }
};