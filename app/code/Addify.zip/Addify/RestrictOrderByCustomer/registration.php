<?php
/**
*
    * @category    PME
    * @package     PME_ExtraProductTab

 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Addify_RestrictOrderByCustomer',
    __DIR__
);
