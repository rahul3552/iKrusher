<?php

namespace Amasty\Faq\Block;

use Magento\Framework\View\Element\Template;

class BackToProduct extends Template
{
    /**
     * @var string
     */
    protected $_template = "back_to_product.phtml";
}
