var config = {
    map: {
        '*': {
            amfaqSearch: 'Amasty_Faq/js/autosuggest'
        }
    }
};
