<?php

namespace Amasty\Faq\Model\Import\Category;

class Import extends \Amasty\Base\Model\Import\AbstractImport
{

}
