<?php

namespace Amasty\Faq\Model\Import\Question;

class Import extends \Amasty\Base\Model\Import\AbstractImport
{

}
