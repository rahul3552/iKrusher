<?php

namespace Amasty\Faq\Model;

class Context
{
    /**
     * selected faq category cache context
     */
    const CONTEXT_CATEGORY = 'faq_category';
}
