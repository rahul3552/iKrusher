<?php

namespace Amasty\Faq\Model;

use Magento\Framework\DataObject;

class DataCollector extends DataObject
{
}
