/**
 * @copyright Copyright © 2020 magesolution. All rights reserved.
 * @author    @copyright Copyright (c) 2014 magesolution (<https://www.magesolution.com>)
 * @license <https://www.magesolution.com/license-agreement.html>
 * @Author: ndthien0912<ndthien0912@gmail.com>
 * @github: <https://github.com/magesolution>
 */
define(['ko'], function (ko) {
    'use strict';
    return {
        isReviewRequired: ko.observable(false),
        customerEmail: ko.observable(null),
        active: ko.observable(false)
    }
});
