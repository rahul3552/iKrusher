<?php

namespace MGS\OSCheckout\Model\Geoip\Maxmind\Db\Reader;

class InvalidDatabaseException extends \Exception
{
}
