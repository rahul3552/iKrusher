var config = {
	"map": {
		"*": {
			"lookbook/owlcarousel": "MGS_Lookbook/js/owl.carousel"
		}
	},
	"paths": {            
		"lookbook/owlcarousel": "MGS_Lookbook/js/owl.carousel"
	},   
    "shim": {
		"MGS_Lookbook/js/owl.carousel": ["jquery"]
	}
};