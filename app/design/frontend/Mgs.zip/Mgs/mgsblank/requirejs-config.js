var config = {
    map: {
        '*': {
			html5shiv: 'js/html5shiv',
			responsive: 'js/responsive',
			theme: 'js/theme'
        }
    }
};