var config = {
	"map": {
		"*": {
			"mgs/isotope": "MGS_Portfolio/js/isotope.pkgd.min",
		}
	},

	"paths": {  
		"mgs/isotope": "MGS_Portfolio/js/isotope.pkgd.min",
	}
};